from flask import Flask, send_file, render_template

# #--

import socketio
import eventlet
import eventlet.wsgi

sio = socketio.Server()
chat = Flask(__name__)

@chat.route('/')
def hello_world():
    return render_template('index.html')

@chat.route('/chat')
def index():
    """Serve the client-side application."""
    return send_file('templates/chat.html')

@sio.on('connect')
def connect(sid, environ):
    print("connect ", sid)

@sio.on('chat message')
def message(sid, data):
    print("message ", data)
    sio.emit('chat message', data=data)

@sio.on('disconnect')
def disconnect(sid):
    print('disconnect ', sid)
    

if __name__ == '__main__':
    # wrap Flask application with engineio's middleware
    chat = socketio.Middleware(sio, chat)

    # deploy as an eventlet WSGI server
    eventlet.wsgi.server(eventlet.listen(('', 80)), chat)
